# Novus Crew - Digital Products Marketplace

A professional full-stack digital marketplace built with React, Vite, and Supabase. Novus Crew enables creators to sell digital products like images, audio, templates, and documents with a complete multi-seller workflow.

## ✨ Features

### 🛍️ Core Store Features
- **Product Catalog**: Browse products with categories, tags, search, and filters
- **Product Details**: Rich product pages with previews, galleries, and reviews
- **Shopping Cart**: Full cart functionality with coupon support
- **Secure Downloads**: Time-limited download links for purchased items
- **Reviews & Ratings**: Customer feedback system
- **Wishlist**: Save products for later

### 👥 Multi-Seller Workflow
- **NC Saler Application**: Public application process for creators
- **Admin Approval**: Admin panel to approve/reject seller applications
- **Seller Dashboard**: Complete seller management with analytics
- **Product Management**: Upload, edit, and manage digital products
- **Revenue Analytics**: Sales tracking and financial insights

### 🔐 User Management
- **Authentication**: Secure email/password auth with Supabase
- **Role-Based Access**: Buyer, Seller (NC Saler), and Admin roles
- **Profile Management**: User profiles with seller verification

### 📊 Admin Panel
- **User Management**: Manage users and seller applications
- **Product Moderation**: Approve and manage all products
- **Analytics Dashboard**: Platform-wide sales and user metrics
- **Commission Management**: Set and track platform fees

## 🚀 Tech Stack

- **Frontend**: React 18 + Vite + Tailwind CSS
- **Backend**: Supabase (PostgreSQL + Auth + Storage)
- **UI Components**: Custom components with Framer Motion
- **Icons**: React Icons (Feather Icons)
- **Forms**: React Hook Form
- **Notifications**: React Hot Toast
- **Charts**: Recharts
- **Routing**: React Router DOM

## 📋 Prerequisites

- Node.js 18+ and npm
- Supabase account
- Stripe account (for payments, optional)

## ⚡ Quick Start

### 1. Clone and Install

```bash
git clone <repository-url>
cd novus-crew
npm install
```

### 2. Setup Supabase

1. Create a new Supabase project at [supabase.com](https://supabase.com)
2. Copy your project URL and anon key
3. Create `.env` file:

```env
VITE_SUPABASE_URL=your-supabase-url
VITE_SUPABASE_ANON_KEY=your-anon-key
```

### 3. Setup Database

1. Go to your Supabase SQL Editor
2. Copy and run the database schema from `src/lib/supabase.js` (DATABASE_SCHEMA constant)
3. This creates all necessary tables, RLS policies, and sample data

### 4. Run Development Server

```bash
npm run dev
```

Visit `http://localhost:5173` to see your application.

## 🗃️ Database Schema

The application uses the following main tables:

- **profiles**: User profiles with roles (buyer/saler/admin)
- **seller_applications**: NC Saler application submissions
- **categories**: Product categories
- **products**: Digital products with files and metadata
- **orders**: Purchase orders and transactions
- **order_items**: Individual items within orders
- **downloads**: Secure download tracking
- **reviews**: Product reviews and ratings
- **wishlists**: User wishlists
- **coupons**: Discount codes

## 👤 User Roles

### Buyer (Default)
- Browse and purchase products
- Leave reviews and manage wishlist
- Access download history

### NC Saler (Approved Seller)
- Upload and manage products
- View sales analytics
- Process payouts
- Customer communication

### Admin
- Approve/reject seller applications
- Moderate all content
- Platform analytics
- User management

## 🔧 Configuration

### Environment Variables

```env
# Required
VITE_SUPABASE_URL=your-supabase-url
VITE_SUPABASE_ANON_KEY=your-anon-key

# Optional
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_stripe_key
VITE_APP_URL=http://localhost:5173
```

### Supabase Setup

1. **Authentication**: Enable email authentication in Supabase Auth settings
2. **Storage**: Create a bucket named "products" for file uploads
3. **RLS**: Row Level Security policies are included in the schema
4. **Email Templates**: Customize auth email templates (optional)

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── ui/             # Basic UI components (Button, Input, etc.)
│   ├── layout/         # Layout components (Header, Footer)
│   ├── auth/           # Authentication components
│   └── products/       # Product-related components
├── contexts/           # React contexts (Auth, Cart)
├── pages/              # Page components
├── lib/                # Utilities and configuration
├── common/             # Shared utilities
└── App.jsx             # Main application component
```

## 🎨 Customization

### Branding
- Update colors in `tailwind.config.js`
- Replace logo and branding in components
- Customize email templates in Supabase

### Features
- Add new product categories
- Implement additional payment methods
- Extend analytics dashboard
- Add social features

## 🚀 Deployment

### Vercel (Recommended)

1. Push code to GitHub
2. Connect repository to Vercel
3. Add environment variables
4. Deploy

### Manual Deployment

```bash
npm run build
# Upload dist/ folder to your hosting provider
```

## 📧 Email Templates

Customize these email scenarios in Supabase:

- **Welcome**: New user registration
- **Application Received**: Seller application submitted
- **Application Approved**: Welcome to NC Saler
- **Application Rejected**: Application feedback
- **Purchase Confirmation**: Order details and downloads

## 🔒 Security Features

- **Row Level Security**: Database-level access control
- **Secure Downloads**: Time-limited signed URLs
- **Input Validation**: Form validation and sanitization
- **Authentication**: Secure JWT-based auth
- **File Upload**: Secure file handling

## 🐛 Troubleshooting

### Common Issues

1. **Supabase Connection**: Check URL and keys in `.env`
2. **Database Errors**: Ensure schema is properly set up
3. **File Uploads**: Check Supabase storage bucket permissions
4. **Authentication**: Verify Supabase auth settings

### Development

```bash
# Check for linting errors
npm run lint

# Build for production
npm run build

# Preview production build
npm run preview
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🙏 Acknowledgments

- Built with [Supabase](https://supabase.com)
- UI inspired by modern marketplace designs
- Icons from [Feather Icons](https://feathericons.com)

---

**Novus Crew** - Empowering creators in the digital marketplace 🚀