import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Card from '../components/ui/Card';
import AuthModal from '../components/auth/AuthModal';
import toast from 'react-hot-toast';
import SafeIcon from '../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const { FiUser, FiMail, FiLink, FiFileText, FiCreditCard, FiCheck } = FiIcons;

const ApplySeller = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset
  } = useForm();

  const onSubmit = async (data) => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('seller_applications')
        .insert([
          {
            user_id: user.id,
            full_name: data.fullName,
            email: data.email,
            portfolio_link: data.portfolioLink,
            sample_work: data.sampleWork,
            vat_gst: data.vatGst,
            payout_details: {
              method: data.payoutMethod,
              details: data.payoutDetails
            }
          }
        ]);

      if (error) throw error;

      toast.success('Application submitted successfully! We\'ll review it and get back to you soon.');
      reset();
      navigate('/');
    } catch (error) {
      console.error('Error submitting application:', error);
      toast.error('Failed to submit application. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const benefits = [
    'Earn up to 90% on each sale',
    'Reach thousands of potential customers',
    'Professional seller dashboard',
    'Detailed analytics and insights',
    'Marketing support and promotion',
    'Secure and timely payouts'
  ];

  const requirements = [
    'High-quality digital products',
    'Original content or proper licensing',
    'Professional product descriptions',
    'Clear preview images/samples',
    'Responsive customer support'
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-gray-900 dark:text-white mb-4"
          >
            Apply as NC Saler
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto"
          >
            Join our community of creators and start earning money by selling your digital products
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Application Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <Card className="p-6">
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">
                Application Form
              </h2>

              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Full Name"
                    icon={FiUser}
                    {...register('fullName', { required: 'Full name is required' })}
                    error={errors.fullName?.message}
                    defaultValue={profile?.full_name || ''}
                  />

                  <Input
                    label="Email Address"
                    type="email"
                    icon={FiMail}
                    {...register('email', {
                      required: 'Email is required',
                      pattern: {
                        value: /^\S+@\S+$/i,
                        message: 'Invalid email address'
                      }
                    })}
                    error={errors.email?.message}
                    defaultValue={profile?.email || ''}
                  />
                </div>

                <Input
                  label="Portfolio Link"
                  icon={FiLink}
                  placeholder="https://your-portfolio.com"
                  {...register('portfolioLink', {
                    required: 'Portfolio link is required',
                    pattern: {
                      value: /^https?:\/\/.+/,
                      message: 'Please enter a valid URL'
                    }
                  })}
                  error={errors.portfolioLink?.message}
                />

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Sample Work Description
                  </label>
                  <textarea
                    className="block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm placeholder-gray-400 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                    rows={4}
                    placeholder="Describe your best work and what makes you a great fit for Novus Crew..."
                    {...register('sampleWork', { required: 'Sample work description is required' })}
                  />
                  {errors.sampleWork && (
                    <p className="text-sm text-red-600 dark:text-red-400">
                      {errors.sampleWork.message}
                    </p>
                  )}
                </div>

                <Input
                  label="VAT/GST Number (Optional)"
                  icon={FiCreditCard}
                  placeholder="Optional for tax purposes"
                  {...register('vatGst')}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Payout Method
                    </label>
                    <select
                      className="block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-primary-500 focus:ring-1 focus:ring-primary-500 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                      {...register('payoutMethod', { required: 'Payout method is required' })}
                    >
                      <option value="">Select payout method</option>
                      <option value="paypal">PayPal</option>
                      <option value="bank">Bank Transfer</option>
                      <option value="stripe">Stripe Connect</option>
                    </select>
                    {errors.payoutMethod && (
                      <p className="text-sm text-red-600 dark:text-red-400">
                        {errors.payoutMethod.message}
                      </p>
                    )}
                  </div>

                  <Input
                    label="Payout Details"
                    placeholder="Email or account details"
                    {...register('payoutDetails', { required: 'Payout details are required' })}
                    error={errors.payoutDetails?.message}
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  loading={loading}
                  disabled={!user}
                >
                  {user ? 'Submit Application' : 'Sign In to Apply'}
                </Button>

                {!user && (
                  <p className="text-sm text-center text-gray-600 dark:text-gray-400">
                    You need to sign in to submit an application.{' '}
                    <button
                      type="button"
                      onClick={() => setIsAuthModalOpen(true)}
                      className="text-primary-600 hover:text-primary-700 font-medium"
                    >
                      Sign in here
                    </button>
                  </p>
                )}
              </form>
            </Card>
          </motion.div>

          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            {/* Benefits */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Seller Benefits
              </h3>
              <ul className="space-y-3">
                {benefits.map((benefit, index) => (
                  <li key={index} className="flex items-start">
                    <SafeIcon 
                      icon={FiCheck} 
                      className="w-5 h-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" 
                    />
                    <span className="text-sm text-gray-600 dark:text-gray-300">
                      {benefit}
                    </span>
                  </li>
                ))}
              </ul>
            </Card>

            {/* Requirements */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Requirements
              </h3>
              <ul className="space-y-3">
                {requirements.map((requirement, index) => (
                  <li key={index} className="flex items-start">
                    <SafeIcon 
                      icon={FiFileText} 
                      className="w-5 h-5 text-primary-500 mt-0.5 mr-3 flex-shrink-0" 
                    />
                    <span className="text-sm text-gray-600 dark:text-gray-300">
                      {requirement}
                    </span>
                  </li>
                ))}
              </ul>
            </Card>

            {/* Process */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Application Process
              </h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center mr-3 mt-0.5">
                    <span className="text-xs font-medium text-primary-600 dark:text-primary-400">1</span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Submit Application</p>
                    <p className="text-xs text-gray-600 dark:text-gray-400">Fill out the form with your details</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center mr-3 mt-0.5">
                    <span className="text-xs font-medium text-primary-600 dark:text-primary-400">2</span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Review Process</p>
                    <p className="text-xs text-gray-600 dark:text-gray-400">We'll review your application within 2-3 days</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-primary-100 dark:bg-primary-900 rounded-full flex items-center justify-center mr-3 mt-0.5">
                    <span className="text-xs font-medium text-primary-600 dark:text-primary-400">3</span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Start Selling</p>
                    <p className="text-xs text-gray-600 dark:text-gray-400">Access your seller dashboard and upload products</p>
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
};

export default ApplySeller;