import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';
import { useCart } from '../../contexts/CartContext';
import Card from '../ui/Card';
import Button from '../ui/Button';
import SafeIcon from '../../common/SafeIcon';
import * as FiIcons from 'react-icons/fi';

const { FiHeart, FiShoppingCart, FiStar, FiDownload } = FiIcons;

const ProductCard = ({ product }) => {
  const { user } = useAuth();
  const { addItem } = useCart();

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addItem(product);
  };

  const handleAddToWishlist = (e) => {
    e.preventDefault();
    e.stopPropagation();
    // TODO: Implement wishlist functionality
  };

  const getPreviewImage = () => {
    if (product.preview_files?.length > 0) {
      return product.preview_files[0];
    }
    return 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&h=300&fit=crop';
  };

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(price);
  };

  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="overflow-hidden group">
        <Link to={`/product/${product.id}`}>
          {/* Image */}
          <div className="relative aspect-[4/3] overflow-hidden">
            <img
              src={getPreviewImage()}
              alt={product.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
            
            {/* Overlay */}
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300" />
            
            {/* Quick Actions */}
            <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 space-y-2">
              <button
                onClick={handleAddToWishlist}
                className="p-2 bg-white dark:bg-gray-800 rounded-full shadow-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              >
                <SafeIcon icon={FiHeart} className="w-4 h-4 text-gray-600 dark:text-gray-400" />
              </button>
            </div>

            {/* Discount Badge */}
            {product.discount_price && (
              <div className="absolute top-3 left-3">
                <span className="bg-red-500 text-white text-xs font-medium px-2 py-1 rounded">
                  {Math.round(((product.price - product.discount_price) / product.price) * 100)}% OFF
                </span>
              </div>
            )}
          </div>

          {/* Content */}
          <div className="p-4">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2">
              {product.title}
            </h3>
            
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-3 line-clamp-2">
              {product.description}
            </p>

            {/* Rating */}
            <div className="flex items-center mb-3">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <SafeIcon
                    key={i}
                    icon={FiStar}
                    className={`w-4 h-4 ${
                      i < Math.floor(product.rating_average || 0)
                        ? 'text-yellow-400 fill-current'
                        : 'text-gray-300 dark:text-gray-600'
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-600 dark:text-gray-400 ml-2">
                ({product.rating_count || 0})
              </span>
              <div className="flex items-center ml-auto text-sm text-gray-500 dark:text-gray-400">
                <SafeIcon icon={FiDownload} className="w-4 h-4 mr-1" />
                {product.download_count || 0}
              </div>
            </div>

            {/* Price */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                {product.discount_price ? (
                  <>
                    <span className="text-lg font-bold text-gray-900 dark:text-white">
                      {formatPrice(product.discount_price)}
                    </span>
                    <span className="text-sm text-gray-500 line-through">
                      {formatPrice(product.price)}
                    </span>
                  </>
                ) : (
                  <span className="text-lg font-bold text-gray-900 dark:text-white">
                    {formatPrice(product.price)}
                  </span>
                )}
              </div>
            </div>

            {/* Add to Cart Button */}
            <Button
              onClick={handleAddToCart}
              className="w-full"
              size="sm"
            >
              <SafeIcon icon={FiShoppingCart} className="w-4 h-4 mr-2" />
              Add to Cart
            </Button>
          </div>
        </Link>
      </Card>
    </motion.div>
  );
};

export default ProductCard;